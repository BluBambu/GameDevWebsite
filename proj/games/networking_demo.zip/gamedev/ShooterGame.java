import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.*;
import java.io.*;
import java.net.*;

public class ShooterGame extends GamePanel {
    public static Socket socket;
    public static PrintWriter out;
    public static BufferedReader in;

	public static void main(String[] args) {
        if (args.length == 2) {
            // Connect to other
            String hostName = args[0];
            int portNumber = Integer.parseInt(args[1]);
            try {
                System.out.println("Attempting to connect...");
                socket = new Socket(hostName, portNumber);
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                System.out.println("Connected");
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(1);
            }
        } else {
            // Get connected to
            int portNumber = 9001;
            try {
                ServerSocket serverSocket = new ServerSocket(portNumber);
                System.out.println("Waiting for connection...");
                socket= serverSocket.accept();
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                System.out.println("Connected");
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
		new ShooterGame(500,500);
	}
	
	public enum Side {
		LEFT, RIGHT, UP, DOWN
	}
	
	public static Random rand = new Random();
	
	public int _player_x, _player_y;
	public boolean _player_dead = false;
	public Side _last_facing;
	public ArrayList<Bullet> _player_bullets = new ArrayList<Bullet>();
	public ArrayList<Enemy> _enemies = new ArrayList<Enemy>(); 

    public boolean left = false;
    public boolean right = false;
    public boolean up = false;
    public boolean down = false;

    public boolean otherLeft = false;
    public boolean otherRight = false;
    public boolean otherUp = false;
    public boolean otherDown = false;
	
	public ShooterGame(int width, int height) {
		super(width, height);
		
		_player_x = this.get_width()/2;
		_player_y = this.get_height()/2;
		_last_facing = Side.UP;
	}
	
	@Override
	public void update() {
		this.clear();
		if (_player_dead) {
			_g.setColor(Color.red);
			_g.drawString("(Press R to respawn)", this.get_width()/2-60, this.get_height()/2);
			if (this.is_key_down(KeyEvent.VK_R)) {
				_player_x = this.get_width()/2;
				_player_y = this.get_height()/2;
				_player_bullets.clear();
				_enemies.clear();
				_player_dead = false;
				
			}
			
		} else {
			if (_g == null) return;
			_g.setColor(Color.black);
			_g.drawString("Arrow keys to move, CTRL to shoot", 0, this.get_height());
			read_network_state();
			update_enemies();
			update_bullets();
		}
        update_player();
	}

    public void read_network_state() {
        try {
            while (in.ready()) {
                String text = "";
                text = in.readLine();
                System.out.println("Other: " + text);
                if (text.equals(Side.UP + " on")) {
                    otherUp = true;
                }
                if (text.equals(Side.UP + " off")) {
                    otherUp = false;
                }
                if (text.equals(Side.DOWN + " on")) {
                    otherDown = true;
                }
                if (text.equals(Side.DOWN + " off")) {
                    otherDown = false;
                }
                if (text.equals(Side.LEFT + " on")) {
                    otherLeft = true;
                }
                if (text.equals(Side.LEFT + " off")) {
                    otherLeft = false;
                }
                if (text.equals(Side.RIGHT + " on")) {
                    otherRight = true;
                }
                if (text.equals(Side.RIGHT + " off")) {
                    otherRight = false;
                }
                if (text.equals("BULLET")) {
                    int bvx = 0, bvy = 0;
                    if (otherRight) {
                        bvx = 8;
                    } else if (otherLeft) {
                        bvx = -8;
                    }
                    if (otherUp) {
                        bvy = -8;
                    } else if (otherDown) {
                        bvy = 8;
                    }
                    Bullet neu = new Bullet(_player_x, _player_y, bvx, bvy);
                    _player_bullets.add(neu);
                }

            }
        } catch (Exception e) {
            System.exit(1);
        }
    }
	
	private void update_player() {
        if (otherUp) {
            _player_y -= 3;
        }
        if (otherDown) {
            _player_y += 3;
        }
        if (otherLeft) {
            _player_x -= 3;
        }
        if (otherRight) {
            _player_x += 3;
        }
		if (this.is_key_down(KEY_UP)) {
            if (!up) {
                System.out.println(Side.UP + " on");
                ShooterGame.out.println(Side.UP + " on");
                up = true;
            }
			_last_facing = Side.UP;
		} else {
            if (up) {
                System.out.println(Side.UP + " off");
                ShooterGame.out.println(Side.UP + " off");
                up = false;
            }
        }
        //-------------
		if (this.is_key_down(KEY_DOWN)) {
            if (!down) {
                System.out.println(Side.DOWN + " on");
                ShooterGame.out.println(Side.DOWN + " on");
                down = true;
            }
			_last_facing = Side.DOWN;
		} else {
            if (down) {
                System.out.println(Side.DOWN + " off");
                ShooterGame.out.println(Side.DOWN + " off");
                down = false;
            }
        }

        //-------------




		if (this.is_key_down(KEY_LEFT)) {
            if (!left) {
                System.out.println(Side.LEFT + " on");
                ShooterGame.out.println(Side.LEFT + " on");
                left = true;
            }
			_last_facing = Side.LEFT;
		} else {
            if (left) {
                System.out.println(Side.LEFT + " off");
                ShooterGame.out.println(Side.LEFT + " off");
                left = false;
            }
        }

		if (this.is_key_down(KEY_RIGHT)) {
            if (!right) {
                System.out.println(Side.RIGHT + " on");
                ShooterGame.out.println(Side.RIGHT + " on");
                right = true;
            }
			_last_facing = Side.RIGHT;
		} else {
            if (right) {
                System.out.println(Side.RIGHT + " off");
                ShooterGame.out.println(Side.RIGHT + " off");
                right = false;
            }
        }

		
		if (this.is_key_down(KeyEvent.VK_CONTROL)) {
            System.out.println("BULLET");
            ShooterGame.out.println("BULLET");
		}
		
		_g.setColor(Color.green);
		_g.fillOval(_player_x-5, _player_y-5, 10, 10);
	}
	
	private void update_bullets() {
		for (int i_bullet = _player_bullets.size()-1; i_bullet >= 0; i_bullet--) {
			Bullet itr_bullet = _player_bullets.get(i_bullet);
			itr_bullet.update(this);
			
			if (!this.point_on_screen(itr_bullet._x, itr_bullet._y)) {
				_player_bullets.remove(itr_bullet);
			}
		}
	}
	
	private void update_enemies() {
		for (int i_enemy = _enemies.size()-1; i_enemy >= 0; i_enemy--) {
			Enemy itr_enemy = _enemies.get(i_enemy);
			itr_enemy.update(this);
			
			boolean do_remove = false;
			for (int i_bullet = _player_bullets.size()-1; i_bullet >= 0; i_bullet--) {
				Bullet itr_bullet = _player_bullets.get(i_bullet);
				if (is_collide(itr_enemy._x, itr_enemy._y, itr_bullet._x, itr_bullet._y, 5 + 3)) {
					_player_bullets.remove(itr_bullet);
					do_remove = true;
					break;
				}
			}
			if (do_remove) {
				_enemies.remove(itr_enemy);
				continue;
			}
			
			if (is_collide(itr_enemy._x, itr_enemy._y, _player_x, _player_y, 5 + 5)) {
				_player_dead = true;
			}
		}
		
		if (rand.nextInt(20)==0) {
			int side = rand.nextInt(4);
			int ex = 0, ey = 0;
			
			if (side == 0) {
				ex = rand.nextInt(this.get_width());
				
			} else if (side == 1) {
				ex = rand.nextInt(this.get_width());
				ey = this.get_height();
				
			} else if (side == 2) {
				ey = rand.nextInt(this.get_height());
				
			} else {
				ex = this.get_width();
				ey = rand.nextInt(this.get_height());
			}
			_enemies.add(new Enemy(ex,ey));
		}
	}
	

	
	private boolean point_on_screen(int x, int y) {
		return (x > 0) && (x < this.get_width()) && (y > 0) && (y < this.get_height());
	}
	
	public boolean is_collide(int x1, int y1, int x2, int y2, int radius_sum){
		double dist = Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2));
		return dist <= radius_sum;
	}
	
	public class Bullet {
		public int _x, _y, _vx, _vy;
		public Bullet(int x, int y, int vx, int vy) {
			_x = x;
			_y = y;
			_vx = vx;
			_vy = vy;
		}
		public void update(ShooterGame game) {
			_x += _vx;
			_y += _vy;
			game._g.setColor(Color.blue);
			game._g.fillOval(_x-3, _y-3, 6, 6);
		}
	}
	
	public class Enemy {
		
		public int _x, _y;
		public Enemy(int x, int y) {
			_x = x;
			_y = y;
		}
		public void update(ShooterGame game) {
			if (rand.nextInt(2)==0) {
				if (_x > game._player_x) {
					_x-=2;
				} else {
					_x+=2;
				}
				
			} else {
				if (_y > game._player_y) {
					_y-=2;
				} else {
					_y+=2;
				}
				
			}
			game._g.setColor(Color.red);
			game._g.fillOval(_x-5, _y-5, 10, 10);
			
		}
	}
	

}
